/*
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.  THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to reproduce and distribute the object code form of the Sample Code, provided that You agree: (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; (ii) to include a valid copyright notice on Your software product in which the Sample Code is embedded; and (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys� fees, that arise or result from the use or distribution of the Sample Code.
Please note: None of the conditions outlined in the disclaimer above will supercede the terms and conditions contained within the Premier Customer Services Description.
*/

-- 1: Create a master key.
-- Only necessary if one does not already exist.
-- Required to encrypt the credential secret in the next step.

CREATE MASTER KEY;

-- 2: Create a database scoped credential
-- IDENTITY: Provide any string, it is not used for authentication to Azure storage.
-- SECRET: Provide your Azure storage account access key.
-- Replace the value with the Access key from your storage account

CREATE DATABASE SCOPED CREDENTIAL asdw_workshop
WITH
    IDENTITY = 'labuser',
    --SECRET = 'xxxxxxxxxxvxxxxxxxxxxxx/kG0HDn0Z3wzf/212sij+KUMO8CDjM8uMHm2VhWe9xxxxxxxxxxxxxxxxxxxx=='
	SECRET ='8QkwepB8pzWY1bOLPLKRm+6JFurfqhhytErTqjJv6XYjWG0ET2jponYcACkjNIrE+7H2A1g0I3UnJwkaBbbrdw=='
;


-- 3: Create an external data source
-- TYPE: HADOOP - PolyBase uses Hadoop APIs to access data in Azure blob storage.
-- LOCATION: Provide Azure storage account name and blob container name.
-- CREDENTIAL: Provide the credential created in the previous step.


-- Replace the location value with your storage account
CR
USE AdventureWorksDW
GO

-- 1: Create a database master key
CREATE MASTER KEY; 
GO

-- 2: Create a database scope credential
CREATE DATABASE SCOPED CREDENTIAL asdw_workshop 
WITH 
    IDENTITY = 'labuser', 
    /*RELACEWITH YOUR ACCESS KEY*/
    SECRET = 'ACCESS_KEY_TO_ADD' 
; 
GO

-- 3: Create an external data source (replace johndoe123 with your account)
CREATE EXTERNAL DATA SOURCE ResellerSales

WITH (
    TYPE = HADOOP,
    LOCATION = 'wasbs://asdw-load@johndoe123.blob.core.windows.net',
    CREDENTIAL = asdw_workshop
);



GO

-- 4: Create an external File Format

-- FORMAT_TYPE: describes the type of sourcefile
-- STRING_DELIMITER: Provide the credential created in the previous step.
-- DATE_FORMAT
-- USE_TYPE_DEFAULT = FALSE 

-- 
CREATE EXTERNAL FILE FORMAT csv_files  
WITH  
(FORMAT_TYPE = DELIMITEDTEXT,
FORMAT_OPTIONS( FIELD_TERMINATOR = ',',
STRING_DELIMITER= '',USE_TYPE_DEFAULT= FALSE) 
); 
GO

CREATE SCHEMA ext; 
GO 


CREATE EXTERNAL TABLE [ext].[New_ResellerSales]
(
	[ProductKey] [bigint] NULL,
	[OrderDateKey] [int] NOT NULL,
	[DueDateKey] [int] NOT NULL,
	[ShipDateKey] [int] NOT NULL,
	[ResellerKey] [int] NOT NULL,
	[EmployeeKey] [int] NOT NULL,
	[PromotionKey] [int] NOT NULL,
	[CurrencyKey] [int] NOT NULL,
	[SalesTerritoryKey] [int] NOT NULL,
	[SalesOrderNumber] [nvarchar](20) NOT NULL,
	[SalesOrderLineNumber] [tinyint] NOT NULL,
	[RevisionNumber] [tinyint] NULL,
	[OrderQuantity] [smallint] NULL,
	[UnitPrice] [money] NULL,
	[ExtendedAmount] [money] NULL,
	[UnitPriceDiscountPct] [float] NULL,
	[DiscountAmount] [float] NULL,
	[ProductStandardCost] [money] NULL,
	[TotalProductCost] [money] NULL,
	[SalesAmount] [money] NULL,
	[TaxAmt] [money] NULL,
	[Freight] [money] NULL,
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[CustomerPONumber] [nvarchar](25) NULL,
	[OrderDate] [datetime] NULL,
	[DueDate] [datetime] NULL,
	[ShipDate] [datetime] NULL
)
WITH
(  
        LOCATION='/ResellerSales',  -- This is the folder which contains our source files
        DATA_SOURCE = ResellerSales,  
        FILE_FORMAT = csv_files  
    ) 
;

-- 6 Now check if you can query the data. Remember the data has not been loaded into your Azure SQL DW yet.

Select COUNT(*) FROM [ext].[New_ResellerSales]

-- 7 Load the new into into the dbo.FactResellerSales table using a CTAS command
CREATE TABLE dbo.FactResellerSales_New
WITH
(Distribution= HASH(ProductKey),
Clustered Columnstore Index)
AS 
SELECT * 
FROM [ext].[New_ResellerSales]
	UNION
SELECT * FROM dbo.FactResellerSales;

 -- Drop the old fact table
 DROP TABLE dbo.FactResellerSales;

 -- Rename the new table
 RENAME OBJECT dbo.FactResellerSales_New TO FactResellerSales;


 -- Check the content of the new table
 SELECT Year(Orderdate) as [Year], COUNT(*) as [Rows]
 FROM dbo.FactResellerSales
 GROUP BY Year(OrderDate)
 ORDER BY Year(OrderDate);
