/*
This Sample Code is provided for the purpose of illustration only and is not intended to be used in a production environment.  THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.  We grant You a nonexclusive, royalty-free right to use and modify the Sample Code and to reproduce and distribute the object code form of the Sample Code, provided that You agree: (i) to not use Our name, logo, or trademarks to market Your software product in which the Sample Code is embedded; (ii) to include a valid copyright notice on Your software product in which the Sample Code is embedded; and (iii) to indemnify, hold harmless, and defend Us and Our suppliers from and against any claims or lawsuits, including attorneys� fees, that arise or result from the use or distribution of the Sample Code.
Please note: None of the conditions outlined in the disclaimer above will supercede the terms and conditions contained within the Premier Customer Services Description.
*/

-- Create two views, one for monitoring CCI row groups and one to estimate the required memory grant to build a CCI on a table

-- CCI rowgroup monitoring view
CREATE VIEW dbo.vw_mon_row_groups
AS
WITH CTE AS
(
SELECT
sch.name as SchemaName,
t.name as TableName,
rg.distribution_id,
rg.Partition_number,
SUM(CASE WHEN rg.state = 1 THEN 1 Else 0 END) as Open_RGs,
SUM(CASE WHEN rg.state = 2 THEN 1 Else 0 END) as Closed_RGs,
SUM(CASE WHEN rg.state = 3 THEN 1 Else 0 END) as Compressed_RGs,
SUM(CASE WHEN rg.state = 1 THEN rg.total_rows  Else 0 END) as Total_Open_RG_rows,
SUM(CASE WHEN rg.state = 2 THEN rg.total_rows  Else 0 END) as Total_Closed_RG_rows,
SUM(CASE WHEN rg.state = 3 THEN rg.total_rows  Else 0 END) as Total_Compressed_RG_rows ,
MIN(CASE WHEN rg.state = 1 THEN rg.total_rows  Else 0 END) as Min_Open_RG_rows,
MAX(CASE WHEN rg.state = 1 THEN rg.total_rows  Else 0 END) as MAX_Open_RG_rows,
AVG(CASE WHEN rg.state = 1 THEN rg.total_rows  Else 0 END) as AVG_Open_RG_rows,
MIN(CASE WHEN rg.state = 2 THEN rg.total_rows  Else 0 END) as MIN_Closed_RG_rows,
MAX(CASE WHEN rg.state = 2 THEN rg.total_rows  Else 0 END) as MAX_Closed_RG_rows,
AVG(CASE WHEN rg.state = 2 THEN rg.total_rows  Else 0 END) as AVG_Closed_RG_rows,
MIN(CASE WHEN rg.state = 3 THEN rg.total_rows  Else 0 END) as MIN_Compressed_RG_rows,
MAX(CASE WHEN rg.state = 3 THEN rg.total_rows  Else 0 END) as MAX_Compressed_RG_rows,
AVG(CASE WHEN rg.state = 3 THEN rg.total_rows  Else 0 END) as AVG_Compressed_RG_rows,
SUM(CASE WHEN rg.state = 3 THEN rg.deleted_rows  Else 0 END) as Deleted_rows,
CASE WHEN  rg.state = 3 THEN trim_reason_desc  END as TrimReason
FROM sys.schemas sch
JOIN sys.tables t ON sch.schema_id = t.schema_id

JOIN [sys].[pdw_table_mappings]ptm ON t.object_id = ptm.object_id
JOIN sys.pdw_nodes_tables nt ON nt.name = ptm.physical_name
JOIN [sys].[dm_pdw_nodes_db_column_store_row_group_physical_stats] rg ON
	rg.object_id = nt.object_id
    AND rg.pdw_node_id = nt.pdw_node_id  
	AND  rg.distribution_id = nt.distribution_id 

	GROUP BY sch.name, t.name,rg.distribution_id,
rg.Partition_number, rg.state, rg.trim_reason_desc
)

SELECT * FROM CTE;





-- Mem grant view
CREATE VIEW dbo.vw_mon_mem_grant
AS
WITH base AS
(SELECT SchemaName,
		TableName,
SUM(Column_count) as Column_Count,
ISNULL(SUM(short_string_count),0) as short_string_columns,
ISNULL(SUM(long_string_count),0) as long_string_columns
FROM
(SELECT sch.name as SchemaName,
t.name as TableName,
COUNT(c.column_id) as Column_count,
CASE WHEN c.[system_type_id] IN (167, 175, 231, 239) AND c.[max_length] <= 32 THEN COUNT(c.column_id) END as short_string_count,
CASE WHEN c.[system_type_id]  IN (167, 175, 231, 239) AND c.[max_length] > 32 THEN COUNT(c.column_id) END as long_string_count
FROM sys.schemas sch
JOIN sys.tables t ON sch.schema_id = t.schema_id
JOIN sys.columns c ON t.object_id = c.object_id
GROUP BY sch.name, t.name, c.system_type_id,c.[max_length]
) a
GROUP BY SchemaName, TableName
)
, size AS
(Select SchemaName, TableName, 75497472 as Table_Overhead,
column_count * 1048576 * 8  as column_size,
short_string_columns * 1048576 * 8  as short_stringcolumn_size,
(long_string_columns * 16777216) - (32 * long_string_columns) as long_stringcolumn_size
FROM base
)
SELECT SchemaName, tableName, 
CAST((Table_overhead * 1.0 + column_size + short_stringcolumn_size + long_stringcolumn_size)/1048576 AS DECIMAL (18,2)) as est_Memgrant_Mb
FROM size;
