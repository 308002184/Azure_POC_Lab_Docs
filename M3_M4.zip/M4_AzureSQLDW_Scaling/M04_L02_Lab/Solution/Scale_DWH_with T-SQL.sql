-- Check your current Azure DWH scale
SELECT
 db.[name] AS [Name],
 ds.[service_objective] AS [ServiceObject]
FROM
sys.database_service_objectives ds
JOIN sys.databases db ON ds.database_id = db.database_id
WHERE ds.edition = 'DataWarehouse';

-- Scale Query 
ALTER DATABASE AdventureworksDW
MODIFY (SERVICE_OBJECTIVE = 'DW200')
;


--Monitoring the scale request
DECLARE @dwh nvarchar(100) ='AdventureWorksDW'
WHILE 
(
SELECT TOP 1
	state_desc
FROM sys.dm_operation_status
WHERE resource_type_desc = 'Database'
	AND major_resource_id = @dwh
	AND operation = 'ALTER DATABASE'
ORDER BY  start_time DESC
) = 'IN_PROGRESS'
BEGIN
RAISERROR('Scale operation in progress',0,0) WITH NOWAIT;
	WAITFOR DELAY '00:00:05';
END
PRINT 'Complete';



-- Check your current Azure DWH scale
SELECT
 db.[name] AS [Name],
 ds.[service_objective] AS [ServiceObject]
FROM
sys.database_service_objectives ds
JOIN sys.databases db ON ds.database_id = db.database_id
WHERE ds.edition = 'DataWarehouse';

