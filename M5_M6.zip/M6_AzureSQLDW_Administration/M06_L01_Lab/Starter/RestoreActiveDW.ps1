﻿
$SubscriptionName="MS Internal PMC Primary"
$ResourceGroupName="meerpmcrg"
$ServerName="pmcsql"  # Without database.windows.net
$DatabaseName="meerreadywh"
$NewDatabaseName="meerreadywhf_restored"

Login-AzureRmAccount

Get-AzureRmSubscription


Select-AzureRmSubscription -SubscriptionName $SubscriptionName

# List the last 10 database restore points
# List the last 10 database restore points
((Get-AzureRMSqlDatabaseRestorePoints -ResourceGroupName $ResourceGroupName -ServerName $ServerName -DatabaseName ($DatabaseName)).RestorePointCreationDate)[-10 .. -1]

# Or list all restore points
Get-AzureRmSqlDatabaseRestorePoints -ResourceGroupName $ResourceGroupName -ServerName $ServerName -DatabaseName $DatabaseName

# Get the specific database to restore
$Database = Get-AzureRmSqlDatabase -ResourceGroupName $ResourceGroupName -ServerName $ServerName -DatabaseName $DatabaseName

# Pick desired restore point using RestorePointCreationDate
$PointInTime="2/26/2018 11:50:51 AM"  

# Restore database from a restore point
$RestoredDatabase = Restore-AzureRmSqlDatabase –FromPointInTimeBackup –PointInTime $PointInTime -ResourceGroupName $Database.ResourceGroupName -ServerName $Database.ServerName -TargetDatabaseName $NewDatabaseName –ResourceId $Database.ResourceID

# Verify the status of restored database
$RestoredDatabase.status

